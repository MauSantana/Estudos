package br.com.banctec.correcaoc13adsa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorrecaoC13adsaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorrecaoC13adsaApplication.class, args);
	}

}
