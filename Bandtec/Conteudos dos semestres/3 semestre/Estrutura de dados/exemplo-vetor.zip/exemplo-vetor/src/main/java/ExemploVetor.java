import java.util.Scanner;

public class ExemploVetor {

    /* Método exibeVetor - recebe um vetor de inteiros e exibe seus valores */
    public static void exibeVetor(int[] v) {
        for (int i = 0; i < v.length; i++) {
            System.out.print("v[" + i + "]= " + v[i] + "\t");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);

        // Declarando um vetor de 5 elementos
        // Tamanho do vetor = 5
        int[] vetor = new int[5];

        // Declarando um vetor com lista de inicializadores
        // ou seja, o vetor já "nasce" com valores
        int[] vet2 = {100, 200, 300, 400};

        // Declarando um terceiro vetor, de String
        String[] vet3 = new String[6];

        // Declarando um quarto vetor, de String, já inicializado com os dias da semana
        String[] diaSemana = {"Domingo", "Segunda", "Terça", "Quarta", "Quinta",
                              "Sexta", "Sábado"};

        // Declarando um quinto vetor, de inteiros, sendo que o tamanho
        // desse vetor será digitado pelo usuário
        int[] vet5;

        int escolha;    // usado para ler a escolha do dia da semana
        int soma = 0;   // usado para calcular a soma dos elementos do vetor
        int contaPares = 0;  // usado para contar a quantidade de pares do vetor
        int tamanho;    // usado para ler o tamanho do vetor vet5

        // Atribuir valores para o vetor
        for (int i = 0; i < vetor.length; i++) {
            vetor[i] = i * 10;
        }

        // Exibir os valores do vetor
        exibeVetor(vetor);
        System.out.println();

        // Exibir os valores do vet2
        exibeVetor(vet2);
        System.out.println();

        // Solicitar para o usuário digitar os valores para preencher o vetor
        for (int i = 0; i < vetor.length; i++) {
            System.out.println("Digite o valor para vetor[" + i + "]");
            vetor[i] = leitor.nextInt();
        }

        // Exibir os valores do vetor
        exibeVetor(vetor);
        System.out.println();

        // Solicitar para o usuário digitar os valores para preencher o vet3
        for (int i = 0; i < vet3.length; i++) {
            System.out.println("Digite o valor para vet3[" + i + "]");
            vet3[i] = leitor.next();
        }

        // Exibir o vet3 usando o for aprimorado
        for (String s : vet3) {
            System.out.print(s + "\t");
        }
        System.out.println();

        // Criar um vetor de Strings já inicializado com os dias da semana,
        // começando por "Domingo"
        // Solicitar que o usuário digite um valor de 1 a 7
        // Ficar num loop até que o usuário digite um valor válido
        // Exibir o dia da semana correspondente (1 - Domingo, 2 - Segunda, etc)

        do {
            System.out.println("Digite um número de 1 a 7");
            escolha = leitor.nextInt();
        } while (escolha < 1 || escolha > 7);

        System.out.println("O dia da semana correspondente é " +
                           diaSemana[escolha-1]);

        // Exibir a soma dos elementos do vetor
        for (int valor : vetor) {
            soma += valor;
        }
        System.out.println("A soma dos valores de vetor é " + soma);

        // Exibir a quantidade de elementos pares do vetor
        for (int valor : vetor) {
            if (valor % 2 == 0) {
                contaPares++;
            }
        }
        System.out.println("A quantidade de pares em vetor é " + contaPares);

        // Solicitar que o usuário digite o tamanho do vetor vet5
        // Esse tamanho terá que ser maior do que 2
        System.out.println("Digite um valor maior do que 2");
        tamanho = leitor.nextInt();

        while (tamanho <= 2) {
            System.out.println("Valor inválido, tente novamente");
            tamanho = leitor.nextInt();
        }

        // Outra forma de validar tamanho, usando while
        // Inicializo tamanho com zero, para forçar a entrar no loop
//        tamanho = 0;
//        while (tamanho <= 2) {
//            System.out.println("Digite um valor maior do que 2");
//            tamanho = leitor.nextInt();
//        }

        // Criar o vetor vet5, com o tamanho digitado pelo usuário
        vet5 = new int[tamanho];

        // Solicitar para o usuário digitar os valores para preencher o vetor
        for (int i = 0; i < vet5.length; i++) {
            System.out.println("Digite o valor para vet5[" + i + "]");
            vet5[i] = leitor.nextInt();
        }

        // Exibir os valores do vetor
        exibeVetor(vet5);
        System.out.println();




    }
}
