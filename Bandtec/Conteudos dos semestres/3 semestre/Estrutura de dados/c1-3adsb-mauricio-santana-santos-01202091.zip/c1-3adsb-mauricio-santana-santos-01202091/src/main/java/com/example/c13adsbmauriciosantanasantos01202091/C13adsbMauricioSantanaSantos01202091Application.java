package com.example.c13adsbmauriciosantanasantos01202091;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C13adsbMauricioSantanaSantos01202091Application {

	public static void main(String[] args) {
		SpringApplication.run(C13adsbMauricioSantanaSantos01202091Application.class, args);
	}

}
