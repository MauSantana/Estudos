package com.example.c13adsbmauriciosantanasantos01202091;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    List<Usuario> usuarios = new ArrayList<>(List.of(
    ));



    @GetMapping("/cadastrar-usuario/{login}/{nome}/{senha}")
    public String cadastrar(@PathVariable String login,
                            @PathVariable String nome,
                            @PathVariable String senha) {
        Usuario novoUsuario
                = new Usuario(nome, login, false, senha);

        usuarios.add(novoUsuario);

        return "Usuário " + nome + " autenticado com sucesso";
    }

    @GetMapping("")
    public List<Usuario> getUsuarios() {
        return usuarios.stream()
                .sorted(Comparator.comparing(Usuario::getNome))
                .collect(Collectors.toList());
    }

//    @GetMapping("/autenticar/{login}/{senha}")
//    public Usuario getValidar(@PathVariable String login,
//                              @PathVariable String senha) {
//        if (login.equals(login) && senha.equals(senha)) {
//
//
//
//        } else {
//            return null;
//        }
    }

//    @GetMapping("/logoff/{login}")
//    public Usuario getValidar(@PathVariable String login,
//                              @PathVariable String senha) {
//        if (login = getUsuarios(login)) {
//            return usuarios.get(login);
//        } else {
//            return null;
//        }