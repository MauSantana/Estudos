package com.example.c13adsbmauriciosantanasantos01202091;

public class Usuario {

    private String nome;
    private String login;
    private Boolean autenticado;
    private String senha;

    public Usuario(String nome, String login, Boolean autenticado, String senha) {
        this.nome = nome;
        this.login = login;
        this.autenticado = autenticado;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Boolean getAutenticado() {
        return autenticado;
    }

    public void setAutenticado(Boolean autenticado) {
        this.autenticado = autenticado;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
