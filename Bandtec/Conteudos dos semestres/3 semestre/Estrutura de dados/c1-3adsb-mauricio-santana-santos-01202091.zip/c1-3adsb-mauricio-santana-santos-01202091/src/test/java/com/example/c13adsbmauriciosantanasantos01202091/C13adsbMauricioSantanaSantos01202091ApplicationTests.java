package com.example.c13adsbmauriciosantanasantos01202091;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C13adsbMauricioSantanaSantos01202091ApplicationTests {

	@Test
	void contextLoads() {
	}

}
