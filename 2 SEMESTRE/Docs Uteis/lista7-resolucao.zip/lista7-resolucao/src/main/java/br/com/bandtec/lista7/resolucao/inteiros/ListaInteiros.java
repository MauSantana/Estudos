package br.com.bandtec.lista7.resolucao.inteiros;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListaInteiros {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        List<Integer> numeros = new ArrayList<>();

        Integer numeroDigitado = 0;

        do {

            System.out.println("Digite um número para adicionar a lista ou 0 para encerrar:");
            numeroDigitado = leitor.nextInt();

            if (!numeroDigitado.equals(0)) {
                numeros.add(numeroDigitado);
            }

        } while (numeroDigitado != 0);

        System.out.println("\nResultado:");

        exibirPares(numeros);

        exibirImpares(numeros);

        Integer soma = somarItensDaLista(numeros);
        System.out.println(String.format("Soma: %d", soma));

        ExibirMaiorEMenor(numeros);
    }

    public static void exibirPares(List<Integer> numeros) {
        System.out.println("\nNúmeros pares:");
        for (Integer numero : numeros) {
            if (numero % 2 == 0) {
                System.out.println(" -> " + numero);
            }
        }
    }

    public static void exibirImpares(List<Integer> numeros) {
        System.out.println("\nNúmeros ímpares:");
        for (Integer numero : numeros) {
            if (numero % 2 != 0) {
                System.out.println(" -> " + numero);
            }
        }
    }

    public static Integer somarItensDaLista(List<Integer> numeros) {
        Integer soma = 0;

        for (Integer numero : numeros) {
            soma += numero;
        }

        return soma;

        // Jeito diferente e mais avançado usando streams...
        // return numeros.stream().mapToInt(Integer::intValue).sum();
    }

    public static void ExibirMaiorEMenor(List<Integer> numeros) {
        Integer menor = numeros.get(0);
        Integer maior = numeros.get(0);

        for (Integer numero : numeros) {
            if (numero < menor) {
                menor = numero;
            }

            if (numero > maior) {
                maior = numero;
            }
        }

        System.out.println(String.format("Maior número: %d", maior));
        System.out.println(String.format("Menor número: %d", menor));
    }
}
