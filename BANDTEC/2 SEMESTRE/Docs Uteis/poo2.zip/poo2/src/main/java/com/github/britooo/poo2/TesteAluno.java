package com.github.britooo.poo2;

/**
 *
 * @author Diego Brito <diego.lima@bandtec.com.br | @Britooo on Github>
 */
public class TesteAluno {

    public static void main(String[] args) {

        Aluno a1 = new Aluno("Diego Brito", "ADS");
        Aluno a2 = new Aluno("Giuliana Miniguiti", "CCO");

//        a1.setNome("Diego Brito");
//        a1.setCurso("ADS");
//        a1.setRa(11111);
//        a1.setNotaFinal(2.4);
//        
//        a1.setNome("Gerson");
//        a1.setNotaFinal(11.0);
        
          System.out.println(a1);

//        System.out.println(String.format("nome: %s, ra: %d, nota final: %.1f",
//                a1.getNome(), a1.getRa(), a1.getNotaFinal()));
//        a2.setNome("Giuliana");
//        a2.setCurso("ADS");
//        a2.setRa(2222);
//        a2.setNotaFinal(8.0);
//        System.out.println(String.format("nome: %s, ra: %d, nota final: %.1f",
//                a2.getNome(), a2.getRa(), a2.getNotaFinal()));
    }
}
