package com.example.vaialipramim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaiAliPraMimApplicationTests {

	@Test
	void contextLoads() {
	}

}
