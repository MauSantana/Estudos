package com.example.importapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImportApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImportApiApplication.class, args);
	}

}
