package com.example.importapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImportApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
