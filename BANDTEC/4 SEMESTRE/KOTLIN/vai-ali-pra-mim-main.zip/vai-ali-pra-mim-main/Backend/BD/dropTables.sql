drop table dbo.post;
drop table dbo.post_visao;
drop table dbo.usuario;
drop table dbo.cartao;
drop table dbo.produto;
drop table dbo.pedido;
