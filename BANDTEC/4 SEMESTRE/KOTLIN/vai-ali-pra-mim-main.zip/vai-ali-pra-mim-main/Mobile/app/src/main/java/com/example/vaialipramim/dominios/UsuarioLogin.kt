package com.example.vaialipramim.dominios

data class UsuarioLogin(

    val email: String,
    val senha: String
)
