let api = "http://vapm-frontend.herokuapp.com"

export default api;