<h1> Vai Ali Pra Mim</h1>
<p> Projeto desenvolvido por:  </p>

<ul>
    <li> <a href="https://github.com/kiviaaraujobandtec"> Kivia Araújo</a> </li>
    <li> <a href="https://github.com/marthasilva"> Martha Ferreira</a> </li>
    <li> <a href="https://github.com/paulorabelobandtec"> Paulo Rabelo</a> </li>
    <li> <a href="https://github.com/pedroabbatebandtec"> Pedro Abbate</a> </li>
    <li> <a href="https://github.com/rubensnascimento"> Rubens Nascimento</a> </li>
    <li> <a href="https://github.com/wellingtonmacena"> Wellington Macena</a> </li>
</ul>

