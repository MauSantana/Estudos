const getToken = () => {
  return "q1u2a3z4a5r6r7u8b9y0d0i1a2m3o4n5d";
};

module.exports = {
  getToken,
};
