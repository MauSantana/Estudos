package com.example.appcomretrofit.models

data class AuthRequest(
    val email: String,
    val password: String,
)
