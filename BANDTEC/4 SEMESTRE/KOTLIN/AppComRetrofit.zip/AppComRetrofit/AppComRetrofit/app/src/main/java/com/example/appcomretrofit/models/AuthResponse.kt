package com.example.appcomretrofit.models

data class AuthResponse(
    val token: String,
)
