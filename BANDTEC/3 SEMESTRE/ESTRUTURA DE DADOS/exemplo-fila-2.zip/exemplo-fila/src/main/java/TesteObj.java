public class TesteObj {
    public static void main(String[] args) {

    }
}
