public interface Tributavel {

    // Todo método dentro de uma interface é abstract
    public Double getValorTributo();
}
