// Como criar elmento HMLT com JS

// var divApp = document.querySelector("app"); < Os dois jeitos buscam

var divApp = document.getElementById("app");

// var titulo = document.createElement("h1");
// titulo.innerHTML = "Crie com JS esse titulo bala";

// divApp.appendChild(titulo);

// Nome de componente pascalCase

function PrimeiroComponente() {
    return (
        <React.Fragment>
        <h1>Crie com JS esse titulo bala</h1>
        <h2>Texto</h2>
        </React.Fragment>
    );
}

ReactDOM.render(PrimeiroComponente(), divApp);