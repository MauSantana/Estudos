public class Teste1 {

    public static void main(String[] args) {
        int a = 9;
        int b = 2;
        double resultado;

        // Casting é usado para que uma variável seja vista
        // como sendo de outro tipo
        resultado = (double) a / b;
        System.out.println("resultado= " + resultado);

        resultado = 1 / 2.0;
        System.out.println("resultado= " + resultado);
    }
}
