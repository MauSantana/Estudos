public interface Funcionario {
    public  Double getValorBonus ();
}
