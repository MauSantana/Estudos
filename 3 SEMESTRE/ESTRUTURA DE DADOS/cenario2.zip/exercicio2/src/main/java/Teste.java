public class Teste {

    public static void main(String[] args) {

        Coordenador c1 = new Coordenador("Antônio",2,20.0,
                31, 30.0);
        Professor p1 = new Professor("José",99,10.0);
        ControleBonus cb1 = new ControleBonus();

        System.out.println("Exibir Bonus Coordenador" + c1.getValorBonus());
        System.out.println("Exibir Bonus Professor" + p1.getValorBonus());

        cb1.registrarBeneficiado(c1);
        cb1.registrarBeneficiado(p1);

        cb1.exibirBeneficiado();

        System.out.println("Exibir Bonus Total" + cb1.calcularTotal());

    }


}
