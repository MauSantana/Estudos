public class Livro extends Produto{

    // Atributos
    private String nome;
    private String autor;
    private String isbn;

    // Construtor
    public Livro(Integer codigo, Double precoCusto, String nome, String autor, String isbn) {
        super(codigo, precoCusto);
        this.nome = nome;
        this.autor = autor;
        this.isbn = isbn;
    }

    // Método
    @Override
    public Double getValorVenda() {
        return this.getPrecoCusto() + (this.getPrecoCusto() * 0.10);
    }

    @Override
    public String toString() {
        return "Livro{" +
                "nome='" + nome + '\'' +
                ", autor='" + autor + '\'' +
                ", isbn='" + isbn + '\'' +
                ", valor da venda final " + getValorVenda() +
                "} " + super.toString();
    }
}
