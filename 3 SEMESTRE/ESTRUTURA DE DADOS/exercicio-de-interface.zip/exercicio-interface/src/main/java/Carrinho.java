import java.util.ArrayList;
import java.util.List;

public class Carrinho {

    // Atributos
    private List<Vendavel> lista;

    // Construtor
    public Carrinho() {
        this.lista = new ArrayList<Vendavel>();
    }

    // Métodos
    public void adicionaVendavel (Vendavel v){
        lista.add(v);
    }

    public Double calculaTotalVenda (){
        Double total = 0.0;
        for (Vendavel v : lista){
            total += v.getValorVenda();
        }
        return total;
    }

    public void exibeItensCarrinho(){
        System.out.println("\n Lista de Itens do carrinho");
        for (Vendavel v : lista)
            System.out.println(v);
    }

}
