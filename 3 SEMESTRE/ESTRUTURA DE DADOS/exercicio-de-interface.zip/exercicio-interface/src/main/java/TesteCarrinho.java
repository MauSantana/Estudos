import java.util.Scanner;

public class TesteCarrinho {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Scanner leitorNL = new Scanner(System.in);

        Integer codigo, quantHoras, opcao;
        String nome, autor, isbn, gravadora, descricao;
        Double precoCusto, valorHora;

        Boolean fim = false;

        Carrinho carrinho = new Carrinho();

        while (!fim){
            System.out.println("Escolha uma opção");
            System.out.println("1- Adicionar Livro");
            System.out.println("2- Adicionar DVD");
            System.out.println("3- Adicionar Serviço");
            System.out.println("4- Exibir itens da Lista");
            System.out.println("5- Exibir total de venda");
            System.out.println("6- Fim");
            opcao = leitor.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o código do livro");
                    codigo = leitor.nextInt();
                    System.out.println("Digite o preço custo do livro");
                    precoCusto = leitor.nextDouble();
                    System.out.println("Digite o nome do Livro");
                    nome = leitorNL.nextLine(); //
                    System.out.println("Digite o Autor do livro");
                    autor = leitorNL.nextLine();
                    System.out.println("Digite o ISBN");
                    isbn = leitorNL.nextLine();
                    Livro l = new Livro (codigo, precoCusto, nome, autor, isbn);
                    carrinho.adicionaVendavel(l);
                    break;

                case 2:
                    System.out.println("Digite o código do dvd");
                    codigo = leitor.nextInt();
                    System.out.println("Digite o preço custo do dvd");
                    precoCusto = leitor.nextDouble();
                    System.out.println("Digite o nome do dvd");
                    nome = leitorNL.nextLine(); //
                    System.out.println("Digite o nome da Gravadora do dvd");
                    gravadora = leitorNL.nextLine();
                    DVD d = new DVD (codigo, precoCusto, nome, gravadora);
                    carrinho.adicionaVendavel(d);
                    break;

                case 3:
                    System.out.println("Digite a descrição do serviço");
                    descricao = leitorNL.nextLine();
                    System.out.println("Digite o código sobre o serviço");
                    codigo = leitor.nextInt();
                    System.out.println("Digite a quantidade de horas de serviço");
                    quantHoras = leitor.nextInt();
                    System.out.println("Digite o valor da hora trabalhada");
                    valorHora = leitor.nextDouble();
                    Servico s = new Servico (descricao, codigo, quantHoras, valorHora);
                    carrinho.adicionaVendavel(s);
                    break;


                case 4:
                    System.out.println("Exibir itens do carrinho");
                    carrinho.exibeItensCarrinho();
                    break;

                case 5:
                    System.out.println(String.format("Total de vendas: R$: %.2f," + carrinho.calculaTotalVenda()));
                    break;

                case 6:
                    fim = true;
                    break;
                default:
                    System.out.println("Opção Inválida. Digite Novamente");
                    break;

            }
        }
}

}
