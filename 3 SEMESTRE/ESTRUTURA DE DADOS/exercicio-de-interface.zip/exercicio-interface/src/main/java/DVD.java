public class DVD extends  Produto{

    // Atributos
    private String nome;
    private String gravadora;

    // Construtor
    public DVD(Integer codigo, Double precoCusto, String nome, String gravadora) {
        super(codigo, precoCusto);
        this.nome = nome;
        this.gravadora = gravadora;
    }

    // Métodos
    @Override
    public Double getValorVenda() {
        return this.getPrecoCusto() + (this.getPrecoCusto() * 0.20);
    }

    @Override
    public String toString() {
        return "DVD{" +
                "nome='" + nome + '\'' +
                ", gravadora='" + gravadora + '\'' +
                ", valor total da venda= " + getValorVenda() +
                "} " + super.toString();
    }
}
